const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

io.on("connection", (socket) => {
  console.log("Un utilisateur est connecté");

  // Chat
  socket.on("message", (msg) => {
    io.emit("message", msg);
  });

  // Synchro vidéo
  socket.on("video:load", (videoId) => {
    socket.broadcast.emit("video:load", videoId);
  });

  socket.on("video:play", (time) => {
    socket.broadcast.emit("video:play", time);
  });

  socket.on("video:pause", (time) => {
    socket.broadcast.emit("video:pause", time);
  });
});

server.listen(3000, () => {
  console.log("Serveur lancé sur http://localhost:3000");
});
